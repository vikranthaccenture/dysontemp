import React, { useEffect, useState } from 'react';
import Loader from "react-js-loader";
import './TestCaseDetails.css';

const TestCaseDetails1 = (props) => {

  const { data } = props;
  const [filesSubmitted, setFilesSubmitted] = useState(false);
  const [numberOfTestCases, setNumberOfTestCases] = useState(0);

  useEffect(() => {
    setFilesSubmitted(props.status);
  }, [props.status]);

  const handleDownload = () => {
    // Call backend API to get the Excel file
    fetch('http://127.0.0.1:5000/api/download-excel', {
      method: 'POST', // Change method to POST
      headers: {
        'Content-Type': 'application/json', // Set content type to JSON
      },
      body: JSON.stringify(data), // Send data to backend
    })
    .then(response => response.blob())
    .then(blob => {
      const url = window.URL.createObjectURL(new Blob([blob]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'test_cases.xlsx'); 
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    })
    .catch(error => console.error('Error downloading Excel file: ', error));
  };

  return (
    <>
    

      {( data && filesSubmitted) && (
        <div className="testCaseDetails">
          <div className='testCaseDetail'>
            <h1 className='heading'>Test Cases</h1>
            <div className='testCaseSelector'>
              <label htmlFor="numberOfTestCases">
                <h3 className='selectText'>Select a test case</h3>
              </label>
              <div className='select'>
                <select
                  id="numberOfTestCases"
                  value={numberOfTestCases}
                  onChange={(e) => setNumberOfTestCases(parseInt(e.target.value))}
                >
                  <option value={0}>Choose test case</option>
                  {data.map((_, index) => (
                    <option key={index + 1} value={index + 1}>Test Case {index + 1}</option>
                  ))}
                </select>
              </div>
            </div>


            {numberOfTestCases > 0 && (
              <>
                <p><strong>Test Case {numberOfTestCases}:</strong><div className='title'>{` ${data[numberOfTestCases - 1].Title}`}</div></p>
                <p><strong>Description:</strong><div className='desc'> {data[numberOfTestCases - 1].Description}</div></p>
                <p><strong>Preconditions:</strong><div className='precondition'>{data[numberOfTestCases - 1].Preconditions}</div></p>
                <p><strong>Post Conditions:</strong> <div className='postcond'> {data[numberOfTestCases - 1].Post_Conditions}</div></p>
                <p><strong>Data Set:</strong></p>
                <div className='dataSet'>
                  <ul>
                    {Object.entries(data[numberOfTestCases - 1].Data_Set).map(([key, value]) => (
                      <li key={key}><strong>{key}:</strong> {value}</li>
                    ))}
                  </ul>
                </div>
                <p><strong>Numbered Steps:</strong></p>
                <div className='numberedSteps'>
                  
                    {data[numberOfTestCases - 1].Numbered_Steps.map((step) => (
                      <li key={`${step.Steps}-${step['Expected Result']}`}> <span>Step:</span>{step.Steps}.<span> Expected Result:</span> {step['Expected Result']}</li>
                    ))}
                  
                </div>
                <p><strong>Regression Steps:</strong></p>
                <div className='regressionSteps'>
                  
                    {data[numberOfTestCases - 1].Regression_Steps.map((step) => (
                      <li key={`${step.Steps}-${step['Expected Result']}`}><span>Step:</span>{step.Steps}.<span>Expected Result:</span> - {step['Expected Result']}</li>
                    ))}
                  
                </div>
              </>
            )}
          </div>
          <button className='downloadButton' onClick={handleDownload}>Download Output Excel File</button>
        </div>
      )}
    </>
  );
};

export default TestCaseDetails1;
