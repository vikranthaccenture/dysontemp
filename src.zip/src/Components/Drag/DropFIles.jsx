import React, { useState } from 'react';
import './DropFiles.css';
import axios from 'axios';
import Vector from '../../assets/Vector.png';
import Vector1 from '../../assets/Vector1.png';
import cross from '../../assets/cross.png';
import Loader from "react-js-loader";

const DropFiles = ({ onDataReceived }) => {
  const [files, setFiles] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedValue, setSelectedValue] = useState('');
  const [selectedStream, setSelectedStream] = useState('');

  const handleDragOver = (event) => {
    event.preventDefault();
  };

  const handleDrop = (event) => {
    event.preventDefault();

    const acceptedFiles = Array.from(event.dataTransfer.files).filter((file) =>
      file.type.match(
        /^(application\/vnd\.openxmlformats-officedocument\.spreadsheetml\.sheet|application\/pdf|text\/csv|application\/msword|application\/vnd\.ms-word)$/ 
      )
    );

    if (acceptedFiles.length > 0) {
      setFiles(acceptedFiles);
    } else {
      alert('Please drag and drop only Excel (XLSX), PDF, CSV, DOCX, or DOC files.');
    }
  };

  const handleFileChange = (event) => {
    const acceptedFiles = Array.from(event.target.files).filter((file) =>
      file.name.match(/\.(xlsx|pdf|csv|docx|doc)$/i));

    if (acceptedFiles.length > 0) {
      setFiles(acceptedFiles);
    } else {
      alert('Please select only Excel (XLSX), PDF, CSV, DOCX, or DOC files.');
    }
  };

  const handleSubmit = () => {
    if (files && selectedValue && (selectedValue !== 'field1_value2' || selectedStream)) {
      setIsLoading(true);

      const formData = new FormData();
      formData.append('selected_lot', selectedValue);
      if (selectedStream) {
        formData.append('selected_stream', selectedStream);
      }

      files.forEach((file) => {
        formData.append('files', file);
      });

      axios
        .post('http://127.0.0.1:5000/api/upload', formData, {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        })
        .then((response) => {
          console.log('Response from server:', response.data);
          
          onDataReceived(response.data);
          setIsLoading(false);
        })
        .catch((error) => {
          console.error('Error uploading file:', error);
          setIsLoading(false);
        });
    } else {
      alert('Please select or drag and drop files and choose a LOT before submitting.');
    }
  };

  const handleCancel = (index) => {
    const updatedFiles = files.filter((file, i) => i !== index);
    setFiles(updatedFiles);
  };

  const handleChange = (event) => {
    setSelectedValue(event.target.value);
    setSelectedStream(''); // Reset the stream when LOT changes
  };

  const handleStreamChange = (event) => {
    setSelectedStream(event.target.value);
  };

  const lotOptions = [
    { value: '', label: 'Choose a LOT' },
    { value: 'field1_value1', label: 'LOT A' },
    { value: 'field1_value2', label: 'LOT B' }
  ];

  const streamOptions = [
    { value: '', label: 'Choose a Stream' },
    { value: 'stream1', label: 'Ariba' },
    { value: 'stream2', label: 'Dione' },
    { value: 'stream3', label: 'Helios' },
    { value: 'stream4', label: 'MDG' },
    { value: 'stream5', label: 'OTC' },
    { value: 'stream6', label: 'PTP' },
    { value: 'stream7', label: 'Retail' },
    { value: 'stream8', label: 'RTR' },
    { value: 'stream9', label: 'SCM' },
  ];

  return (
    <>
      <div className="mainCont">
        <h2 className="h2">User Story to Test Case Demo</h2>
        <div className="dropzone">
          <div className="sel">
            <div className="selectLotText">Select a LOT</div>
            <div className="selectLOt">
              <select value={selectedValue} onChange={handleChange}>
                {lotOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
          {selectedValue === 'field1_value2' && (
            <div className="sel">
              <div className="selectLotText">Select a Stream</div>
              <div className="selectLOt">
                <select value={selectedStream} onChange={handleStreamChange}>
                  {streamOptions.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}
          <div className="drag">
            <div className="fileSubmit" onDragOver={handleDragOver} onDrop={handleDrop}>
              <div className="dragging">
                <img src={Vector} alt="drag files" className="vector" />
                <div className="text">
                  <h4 className="dragText">Drag and Drop file here</h4>
                  <h6 className="sizeText">Limit 200MB per file+(xlsx,pdf,csv,docx,doc)</h6> 
                </div>

                <button className="browseButton" onClick={() => document.getElementById('fileInput').click()}> Browse Files </button>

                <input type="file" id="fileInput" accept=".xlsx,.pdf,.csv,.docx,.doc" className="fileInput" multiple onChange={handleFileChange} style={{ display: 'none' }} /> 
              </div>
              <div className="submission">
                {files && (
                  <ul>
                    {files.map((file, index) => (
                      <li key={index}>
                        <div className="afterSubmit">
                          <img src={Vector1} alt="Vector1" className="vector" />
                          {file.name}
                          <button className="crossButton" onClick={() => handleCancel(index)}><img src={cross} alt="Cross" className="cross" /></button>
                          <div className="submit">
                            <button onClick={handleSubmit} className="submitButton">Submit</button>
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
      {isLoading &&
        <div className='loader'>
          <div className='generateText'><h2>Generating Test Cases...</h2></div>
          <div className={"item"}>
            <Loader type="spinner-circle" bgColor="#000000" color="#ffffff" size={100} />
          </div>
        </div>
      }
    </>
  );
};

export default DropFiles;
