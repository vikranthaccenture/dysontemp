

import React, { useState } from 'react';
import Header from './Components/Header/Header';
import DropFiles from './Components/Drag/DropFIles';
import TestCaseDetails1 from './Components/TestCases/TestCaseDetails1';

function App() {
  const [testCaseData, setTestCaseData] = useState(null);

  const handleDataReceived = (data) => {
    setTestCaseData(data);
  };

  return (
    <div className="app">
      <Header />
      <div className='mainAA'>
        <DropFiles onDataReceived={handleDataReceived} /> 
        
     <TestCaseDetails1 data={testCaseData} status={true} />
      </div>
    </div>
  );
}

export default App;
