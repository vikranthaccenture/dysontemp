import streamlit as st
import pandas as pd
from langchain.document_loaders import PyPDFLoader
# import boto3
# import botocore
import json
import openpyxl
import re
import os
from langchain.document_loaders import UnstructuredWordDocumentLoader
import io
from io import BytesIO
from bs4 import BeautifulSoup
from PIL import Image
# from DysonDataSearch import *
import ast
from dotenv import load_dotenv
# from generate import *
from pathlib import Path
import pdfplumber
from flask import Flask, flash, request, redirect, url_for

app = Flask(__name__)

testCase = []

## for uploading file
@app.route('/upload', methods=['POST'])
def upload():
    if request.method == 'POST':
        # FileStorage object wrapper
        uploaded_file = request.files["file"]                    



        primer = """You are reviewing user stories that will add new features to a management system app. 
        The contents of the user story are contained in <context> tags.
        \nThe specific instructions for this content are in the <prompt> tags."""


        print("Clicked Submit--")
        if uploaded_file is not None:
            #file type check
            # filetype = Path(uploaded_file.name).suffix
            # pdf_format(uploaded_file)
            print(uploaded_file.filename)
            filename = uploaded_file.filename
            format_type = '.' in filename and filename.rsplit('.', 1)[1]
            # format_type = Path(uploaded_file.name).suffix 
            format_type = "."+format_type
            print(format_type)
            if format_type == ".xlsx":
                print("file is csv")
                # with open("temp/temp.pdf", "wb") as f:
                #     f.write(uploaded_file.read())
                # print("uploaded file ", uploaded_file)
                columns=["Description","Acs"]
                df_xls=pd.read_excel(uploaded_file, sheet_name='Stories')
                df2 = pd.DataFrame(df_xls.values.tolist())
                print("df2",df2)
                # print("df2[4].values.tolist()[0]", df2[4].values.tolist()[0].split("###"))
                # acceptance_criteria=df2[4].values.tolist()[0].split("###")
                acceptance_criteria=df2[4].values.tolist()[0].split("AC")
                first_row_data = "user stroy :"+ df2[3].values.tolist()[0] + "acceptance criteria : "+df2[4].values.tolist()[0]
                print("acceptance_criteria",acceptance_criteria)
                print("length",len(acceptance_criteria))
                
                ############################################################
                data_set=[]
                st.write("### Generating Test Cases ...")
                print("Line 327")
                for index, item in enumerate(acceptance_criteria):
                    if(item!=""):
                        # print("item", item)
                        # print("index", index)
                        data_set=get_dataSet(item)

                        newItem="user stroy :"+ df2[3].values.tolist()[0] + "acceptance criteria  : "+item
                        # print("new :::::",newItem)

                        output = generate_text(primer, newItem, data_set)
                        output=output.split(":",1)[1].strip()
                        # print(ast.literal_eval(output))
                        
                        soup = BeautifulSoup(output, 'html.parser')
                        output = soup.get_text()
                        if(output.split(":",1)[0]=="Test_Case"):
                            output=str(output.split(":",1)[1])
                        print("output---",output)
                        output.replace("false", "False")
                        output.replace("true", "True")
                        output=ast.literal_eval(output)
                        # print("OUTPUT :::::::::::::::::::::::::::",output)
                        # print("typeof ",type(output))
                        for out in output:
                            testCase.append(out)
                        st.markdown(f"Test Case {index} : ")
                        # st.json(data)
                        # print("data.items", data)
                        # # Display each key and value dynamically

                        display_data(output)
                ############################################################
                file = uploaded_file.name.split(".")[0]
                flat_data = pd.json_normalize(testCase)
                expanded_data = pd.DataFrame()
            elif format_type == ".pdf":
                print("file is pdf")
                pdfData = pdf_format(uploaded_file)
                print(pdfData['Reference'])
                for refs in pdfData['Reference']:
                    print(refs)
                    
                    if(refs!=""):
                        # print("item", item)
                        # print("index", index)
                        data_set=get_dataSet(refs['acceptance'])

                        newItem="user stroy :"+ refs['Description'] + "acceptance criteria  : "+refs['acceptance']
                        # print("new :::::",newItem)

                        output = generate_text(primer, newItem, data_set)
                        output=output.split(":",1)[1].strip()
                        # print(ast.literal_eval(output))
                        
                        soup = BeautifulSoup(output, 'html.parser')
                        output = soup.get_text()
                        if(output.split(":",1)[0]=="Test_Case"):
                            output=str(output.split(":",1)[1])
                        print("output---",output)
                        output.replace("false", "False")
                        output.replace("true", "True")
                        output=ast.literal_eval(output)
                        # print("OUTPUT :::::::::::::::::::::::::::",output)
                        # print("typeof ",type(output))
                        for out in output:
                            testCase.append(out)
                        st.markdown(f"Test Case {refs['AC_REF']} : ")
                        # st.json(data)
                        # print("data.items", data)
                        # # Display each key and value dynamically

                        display_data(output)
                ############################################################
                file = uploaded_file.name.split(".")[0]
                flat_data = pd.json_normalize(testCase)
                expanded_data = pd.DataFrame()

            elif format_type == ".csv":
                print("file is csv")
                csvData = csv_format(uploaded_file)
                # print(csvData[3]['Acceptance Criteria'])
                # csv = csvData[3]['Acceptance Criteria']
                # accc = csv.split("*AC")
                # print(len(accc))

                for refs in csvData:
                    # print(refs['Acceptance Criteria'])
                    
                    if(refs!="" and str(refs['Acceptance Criteria'])!="nan" and str(refs['Description'])!="nan"):
                        # print("item", item)
                        # print("index", index)
                        csv = refs['Acceptance Criteria']
                        print(csv)
                        print(type(csv))
                        if '*AC' in csv:
                            accepatnace = csv.split("*AC")
                        elif '*Scenario' in csv:
                            accepatnace = csv.split("*Scenario")
                        for index, item in enumerate(accepatnace):
                            if(item!=""):
                                data_set=get_dataSet(item)

                                newItem="user stroy :"+ refs['Description'] + "acceptance criteria  : "+item
                                # print("new :::::",newItem)

                                output = generate_text(primer, newItem, data_set)
                                output=output.split(":",1)[1].strip()
                                # print(ast.literal_eval(output))
                                
                                soup = BeautifulSoup(output, 'html.parser')
                                output = soup.get_text()
                                if(output.split(":",1)[0]=="Test_Case"):
                                    output=str(output.split(":",1)[1])
                                print("output---",output)
                                output.replace("false", "False")
                                output.replace("true", "True")
                                # output = output[output.find('{'):]
                                if (output[0] == '['):
                                    output = ast.literal_eval(output)
                                    print("output list type: ", output)
                                    for out in output:
                                        out['TestCase'] = refs['Issue key']
                                        testCase.append(out)
                                        st.markdown(f"Test Case {refs['Issue key']} : ")
                                        out_list = []
                                        print("out: ", out)
                                        out_list.append(out)
                                        display_data(out_list)
                                else:
                                    output=ast.literal_eval(output)
                                    # print("OUTPUT :::::::::::::::::::::::::::",output)
                                    # print("typeof ",type(output))
                                    output['TestCase'] = refs['Issue key']
                                    testCase.append(output)
                                    st.markdown(f"Test Case {refs['Issue key']} : ")
                                    display_data(output)
                ############################################################
                file = uploaded_file.name.split(".")[0]
                flat_data = pd.json_normalize(testCase)
                expanded_data = pd.DataFrame()
            


            # for entry in testCase:
            #     general_info = {
            #         "User_Story":entry['TestCase'],
            #         "Title": entry["Title"],
            #         "Description": entry["Description"],
            #         "Post_Conditions": entry["Post_Conditions"],
            #         "Preconditions": entry["Preconditions"],
            #         "Data_Set": json.dumps(entry["Data_Set"]),
            #     }

            #     #### for matching length for both list
            #     a = entry["Numbered_Steps"]
            #     b = entry["Regression_Steps"]
            #     lenA, lenB = len(a), len(b)
            #     diff=abs(len(a)-len(b))
            #     if lenA < lenB: 
            #         a.extend([0]*diff)
            #     else: 
            #         b.extend([0]*diff)
            #     #######################

            #     for i, (num_step, reg_step) in enumerate(zip(a, b)):
            #         if  num_step == 0:
            #             continue
            #         if i == 0:
            #             row_data = {**general_info}
            #         else:
            #             row_data = {key: "" for key in general_info}
            #         row_data.update({
            #             "Numbered_Steps_Steps": num_step["Steps"] if "Steps" in num_step else num_step["Step"],
            #             "Numbered_Steps_ExpectedResult": num_step["Expected Result"]
            #             # "Regression_Steps_steps": reg_step["Steps"] if "Steps" in reg_step else reg_step["Step"],
            #             # "Regression_Steps_ExpectedResult": reg_step["Expected Result"]
            #         })


            #         expanded_data = pd.concat([expanded_data, pd.DataFrame([row_data])], ignore_index=True)
            # output_file_name = 'output/'+file+'_Test_Cases.xlsx'
            # expanded_data.to_excel(output_file_name, index=False)




        
#         primer = """You are reviewing user stories that will add new features to a management system app. 
# The contents of the user story are contained in <context> tags.
# \nThe specific instructions for this content are in the <prompt> tags."""
#         prompt = """for each test case, write a numbered steps : section which is broken down into a Description: section and an Expected Result: section for each step. Give specific input and output values where possible. Give enough detail that a selenium script can be written for these steps.
#         \nDo not include the tags in your response. 
# \nDo not start your response with 'Here is...' or 'Here are...'."""
#         output = output + "\n" + generate_steps(primer, prompt, first_row_data)
#         output = output.replace('<format>','').replace('</format>','')
#         print("Second output :  ",output)
#         testCase = testCase + f"\n{output}"
        ############################################################
        # st.write("### Generated Test Cases :")
        # st.markdown(testCase)
        ############################################################
#         primer = """You are reviewing UAT test case scripts for a management system app and your job is to write regression test scripts in accompaniment. 
# The contents of the user story are contained in <context> tags. 
# \nThe existing UAT test script is in <test-script> tags.
# \nThe specific instructions for this content are in the <prompt> tags."""
#         prompt = """Using each step in the test script, provide additional positive and negative regression test steps for each process.
#         \nWrite a numbered Steps: section which is broken down into a Description: section and an Expected Result: section for each step. Give specific input and output values where possible. Give enough detail that a selenium script can be written for these steps.
#         \nSteps on the same page should follow each other.
#         \nDo not include the tags in your response. 
#         \nDo not start your response with 'Here is...' or 'Here are...'."""

#         st.markdown(testCase)
#         file = uploaded_file.name
#         regr=''
#         for item in testCase:
#             regr1 = generate_regr_steps(primer, prompt, first_row_data, item)
#             regr = regr + regr1.replace('<format>','').replace('</format>','')
#             print("regr : ",regr)

            
#         st.write("\n\n### Regression Steps")
#         st.write(regr)
        ############################################################
        # # Convert dictionary to JSON
        # json_data = json.dumps(testCase, indent=2)
        # data = json.loads(json_data)
        # print("json_data", json_data)

        # # Create a new Excel workbook
        # workbook = openpyxl.Workbook()

        # # Create a new sheet
        # sheet = workbook.active
        # sheet.title = "TestCasesData"

        # # Set column names
        # column_names = ['Title', 'Description', 'Post_Conditions', 'Preconditions', 'Data_Set', 'Step', 'Expected_Result']
        # sheet.append(column_names)

        # # Iterate through each test case and its steps
        # for test_case in data:
        #     # Write test case information in one row
        #     row_data = [
        #         test_case.get('Title', ''),
        #         test_case.get('Description', ''),
        #         test_case.get('Post_Conditions', ''),
        #         test_case.get('Preconditions', ''),
        #         test_case.get('Data_Set', ''),
        #         '',  # Leave an empty cell for steps
        #         ''
        #     ]
        #     sheet.append(row_data)

        #     # Write steps in subsequent rows
        #     for step in test_case.get('Numbered_Steps', []):
        #         step_data = ['', '', '', '', '', step.get('Step', ''), step.get('Expected Result', '')]
        #         sheet.append(step_data)

        #     # Write regression steps in subsequent rows
        #     for regression_step in test_case.get('Regression_Steps', []):
        #         regression_step_data = ['', '', '', '', '', regression_step.get('Step', ''), regression_step.get('Expected Result', '')]
        #         sheet.append(regression_step_data)

        # # Save the workbook
        # workbook.save("test_case_data_from_json.xlsx")
        ############################################################

        #doc = create_xlsx(output, regr, file)
        

        #new_df = pd.DataFrame([[file, as_a_user, output]], columns=df.columns)
        #df = pd.concat([df, new_df])
        

        #st.markdown("### Selenium Script")
        #primer = "You are reading the Steps section of a test script (contained in <context> tags) for a Health and Human Services Management System application and creating selenium scrips based off of the steps."
        #prompt = "Based on the Steps section, can you write a selenium script to perform the test case?"
        #script = generate_script(primer, prompt, output)
        #st.markdown(script)



#df.to_csv('out.csv')


if __name__ == '__main__':
   app.run(port=5000)